package com.example.acer.nationalnews;


import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Nentity.class}, version = 1)

public abstract class FavNewsDB extends RoomDatabase {

    public abstract FavRoomDao favDao();

    private static volatile FavNewsDB INSTANCE;

    static FavNewsDB getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (FavNewsDB.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            FavNewsDB.class, "Room_database")
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
