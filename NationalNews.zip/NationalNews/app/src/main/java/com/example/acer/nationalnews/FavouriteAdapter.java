package com.example.acer.nationalnews;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


class FavouriteAdapter extends RecyclerView.Adapter<FavouriteAdapter.ViewHolder> {
    Context ct;
    ArrayList<Nentity> favnewsdata;


    public FavouriteAdapter(FavActivityScreen favActivityScreen, ArrayList<Nentity> nentit) {
        this.ct=favActivityScreen;
        this.favnewsdata=nentit;

    }


    @NonNull
    @Override
    public FavouriteAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return  new ViewHolder(LayoutInflater.from(ct).inflate(R.layout.data,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull FavouriteAdapter.ViewHolder viewHolder, int i) {
        Picasso.with(ct).load(favnewsdata.get(i).getImage()).into(viewHolder.imageView);
        viewHolder.textView.setText(favnewsdata.get(i).getTitle());
    }

    @Override
    public int getItemCount() {
        return favnewsdata.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView=itemView.findViewById(R.id.maintext);
            imageView=itemView.findViewById(R.id.images);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position=getAdapterPosition();
                    Intent i=new Intent(ct,TrendDetailsActivity.class);

                    i.putExtra("image",favnewsdata.get(position).getImage());
                    i.putExtra("title",favnewsdata.get(position).getTitle());
                    i.putExtra("author",favnewsdata.get(position).getAuthor());
                    i.putExtra("description",favnewsdata.get(position).getDescription());
                    i.putExtra("content",favnewsdata.get(position).getContent());
                    i.putExtra("publishedat",favnewsdata.get(position).getPublisedat());
                    i.putExtra("moreinfo",favnewsdata.get(position).getMoreinfo());
                    ct.startActivity(i);
                }
            });

        }
    }
}
