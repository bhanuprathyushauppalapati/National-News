package com.example.acer.nationalnews;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class FavRepos {
    private FavRoomDao favRoomDao;
    private LiveData<List<Nentity>> getfavorites;

    FavRepos(Application application)

    {
        FavNewsDB newsDB=FavNewsDB.getDatabase(application);
        favRoomDao=newsDB.favDao();
        getfavorites=favRoomDao.getfavorites();
    }

    LiveData<List<Nentity>> getGetfavorites(){
        return getfavorites;
    }



    public void insert(Nentity nentity){
        new insertAsyncTask(favRoomDao).execute(nentity);

    }

    public void deleteData(Nentity nentity)
    {
        new deleteAsync(favRoomDao).execute(nentity);
    }

    private class insertAsyncTask extends AsyncTask<Nentity ,Void, Void>
    {
        FavRoomDao dao;
        public insertAsyncTask(FavRoomDao favRoomDao)
        {
            this.dao=favRoomDao;
        }

        @Override
        protected Void doInBackground(Nentity... nentities) {
            dao.insertData(nentities[0]);
            return null;
        }
    }

    private class deleteAsync extends AsyncTask<Nentity,Void,Void>
    {
        FavRoomDao deleteDao;

        public deleteAsync(FavRoomDao favRoomDao) {
            this.deleteDao=favRoomDao;
        }

        @Override
        protected Void doInBackground(Nentity... nentities)
        {
            deleteDao.delete(nentities[0]);
            return null;
        }
    }

}
