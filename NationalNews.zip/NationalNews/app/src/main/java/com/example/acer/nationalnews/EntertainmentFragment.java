package com.example.acer.nationalnews;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.

 */
public class EntertainmentFragment extends Fragment {
    RequestQueue requestQueue;
    RecyclerView recyclerView;
    ArrayList<Pojo>elist;

    public EntertainmentFragment() {
        // Required empty public constructor
    }






    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

       View view=inflater.inflate(R.layout.fragment_entertainment, container, false);
       requestQueue=Volley.newRequestQueue(getContext());
       recyclerView=view.findViewById(R.id.recent);
       elist=new ArrayList<>();


       String enterlist="https://newsapi.org/v2/top-headlines?country=in&category=entertainment&apiKey=9c265d97d4a249fb94d18e0ded18b899";
        StringRequest request=new StringRequest(Request.Method.GET, enterlist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("articles");

                    Toast.makeText(getContext(), ""+jsonArray.length(), Toast.LENGTH_SHORT).show();
                    for (int i = 0; i <jsonArray.length() ; i++) {
                        JSONObject object=jsonArray.getJSONObject(i);
                      String author   =   object.getString("author");
                        String titles  = object.getString("title");

                        String  desc=object.getString("description");
                        String urllink=object.getString("url");
                        String urlImage=object.getString("urlToImage");
                        String publishedat=object.getString("publishedAt");
                        String contents=object.getString("content");

                        Pojo p=new Pojo(author,titles,desc,urllink,urlImage,publishedat,contents);

                        elist.add(p);
                    }
                    MyAdapter myAdapter=new MyAdapter(getContext(),elist);
                    recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                    recyclerView.setAdapter(myAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }





            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(request);



       return view;
    }


}
