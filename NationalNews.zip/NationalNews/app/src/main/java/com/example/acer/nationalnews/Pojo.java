package com.example.acer.nationalnews;

import android.os.Parcel;
import android.os.Parcelable;

class Pojo implements Parcelable {

    String author;
    String titles;
    String desc;
    String urllink;
    String urltoimage;
    String publishedat;
    String contents;
    public Pojo(String author, String titles, String desc, String urllink, String urlImage, String publishedat, String contents) {

   this.author=author;
   this.titles=titles;
   this.desc=desc;
   this.urllink=urllink;
   this.urltoimage=urlImage;
   this.publishedat=publishedat;
   this.contents=contents;
   }

    protected Pojo(Parcel in) {
        author = in.readString();
        titles = in.readString();
        desc = in.readString();
        urllink = in.readString();
        urltoimage = in.readString();
        publishedat = in.readString();
        contents = in.readString();
    }

    public static final Creator<Pojo> CREATOR = new Creator<Pojo>() {
        @Override
        public Pojo createFromParcel(Parcel in) {
            return new Pojo(in);
        }

        @Override
        public Pojo[] newArray(int size) {
            return new Pojo[size];
        }
    };

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitles() {
        return titles;
    }

    public void setTitles(String titles) {
        this.titles = titles;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getUrllink() {
        return urllink;
    }

    public void setUrllink(String urllink) {
        this.urllink = urllink;
    }

    public String getUrltoimage() {
        return urltoimage;
    }

    public void setUrltoimage(String urltoimage) {
        this.urltoimage = urltoimage;
    }

    public String getPublishedat() {
        return publishedat;
    }

    public void setPublishedat(String publishedat) {
        this.publishedat = publishedat;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(author);
        parcel.writeString(titles);
        parcel.writeString(desc);
        parcel.writeString(urllink);
        parcel.writeString(urltoimage);
        parcel.writeString(publishedat);
        parcel.writeString(contents);
    }
}
