package com.example.acer.nationalnews;


import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface FavRoomDao {

    @Insert
    void insertData(Nentity newsdata);

    @Delete
    void  delete (Nentity favnewsdata);

    @Query("Select* from Favorites")
    LiveData<List<Nentity>> getfavorites();



}
