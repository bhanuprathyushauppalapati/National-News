package com.example.acer.nationalnews;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import static com.android.volley.VolleyLog.TAG;

class NewsIntentServiceclass extends IntentService {
    public NewsIntentServiceclass(String name) {
        super("NewsIntentServiceclass");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        if (intent != null) {
            if (intent.getAction().equals("IntentServiceAction")) {
                Log.d(TAG, "onHandleIntent: ");
                Intent i = new Intent("HomewigetAppTest", null, getApplicationContext(), NewAppWidget.class);
                i.setAction("HomewigetAppTest");
                sendBroadcast(i);
            }
        }
    }
}
