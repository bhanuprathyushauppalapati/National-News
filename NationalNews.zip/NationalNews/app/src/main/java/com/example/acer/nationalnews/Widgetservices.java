package com.example.acer.nationalnews;

import android.content.Intent;
import android.widget.RemoteViewsService;

public class Widgetservices extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new WidgetData(this,intent);
    }
}