package com.example.acer.nationalnews;

import android.appwidget.AppWidgetManager;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TrendDetailsActivity extends AppCompatActivity {
    ImageView imageV;
    TextView titletext,authortext,pubtext,
            destext,conttext,infotext;
    public static final String Images="image";
    public static final String Title="title";
    RequestQueue requestQueue;
    String t,a,p,d,c,i,img,id;
    LikeButton imageView;
    FavModel favModel;

    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trend_details);
        imageV=findViewById(R.id.imagenext);
        titletext=findViewById(R.id.titleid);
        authortext=findViewById(R.id.authorid);
        pubtext=findViewById(R.id.pubid);
        destext=findViewById(R.id.descid);
        conttext=findViewById(R.id.contentid);
        infotext=findViewById(R.id.moreinfoid);
        MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);





        img=getIntent().getStringExtra("image");
        t=getIntent().getStringExtra("title");
        a=getIntent().getStringExtra("author");
        p=getIntent().getStringExtra("publishedat");
        d=getIntent().getStringExtra("description");
        c=getIntent().getStringExtra("content");
        i=getIntent().getStringExtra("info");

         titletext.setText(t);
         Picasso.with(this).load(img).into(imageV);
         authortext.setText(a);
         pubtext.setText(p);
         destext.setText(d);
         conttext.setText(c);
         infotext.setText(i);


         favModel = ViewModelProviders.of(this).get(FavModel.class);
        imageView=findViewById(R.id.favImg);
        imageView.setOnLikeListener(new OnLikeListener(){

            @Override
            public void liked(LikeButton likeButton) {
                saveToRoom();
            }

            @Override
            public void unLiked(LikeButton likeButton) {

                deleteFromRoom();
            }
        });
NewsCheck();
    }



    public void saveToRoom() {
        Nentity nentity = new Nentity();
        nentity.setTitle(t);
        nentity.setAuthor(a);
        nentity.setContent(c);
        nentity.setImage(img);
        nentity.setDescription(d);
        nentity.setPublisedat(p);
        nentity.setMoreinfo(i);
        favModel.insertData(nentity);
        Toast.makeText(this, getString(R.string.dataadd), Toast.LENGTH_SHORT).show();

    }
    public void deleteFromRoom() {
        Nentity nentity = new Nentity();
        nentity.setTitle(t);
        nentity.setAuthor(a);
        nentity.setImage(img);
        nentity.setContent(c);
        nentity.setDescription(d);
        nentity.setPublisedat(p);
        nentity.setMoreinfo(i);
        favModel.deleteData(nentity);
        Toast.makeText(this, getString(R.string.datadel), Toast.LENGTH_SHORT).show();
}

    public void NewsCheck()
    {
       favModel.getLiveData.observe(this, new Observer<List<Nentity>>() {
           @Override
           public void onChanged(@Nullable List<Nentity> nentities) {
               for (int i=0;i<nentities.size();i++)
               {
                   String ti=nentities.get(i).getTitle();
                   if (ti.equalsIgnoreCase(t))
                   {
                       imageView.setLiked(true);
                   }
               }
           }
       });
    }
    public  void AddToWidget(MenuItem item)
    {
        SharedPreferences sharedPreferences=getSharedPreferences("file",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();

        StringBuilder builder=new StringBuilder();
        Bundle arguments=getIntent().getExtras();
        d=arguments.getString("description");
        t=arguments.getString("title");
        builder.append(getString(R.string.maintitle)+t+"\n\n"+getString(R.string.descriptive)+"\t"+d);
        editor.putString("appwidget","\t\t\t\t"+builder.toString());
        editor.apply();

        Intent intent= new Intent(this,NewAppWidget.class);
        intent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        int id[] = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(),NewAppWidget.class));
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,id);
        sendBroadcast(intent);
        Toast.makeText(this, getString(R.string.newsadded), Toast.LENGTH_SHORT).show();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.widgetmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public void info(View view) {
        Uri uri=Uri.parse(i);
        Intent intent=new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
    }

}
