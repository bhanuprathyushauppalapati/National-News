package com.example.acer.nationalnews;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    RequestQueue requestQueue;
    ArrayList<Pojo>list;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestQueue = Volley.newRequestQueue(this);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        list=new ArrayList<>();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        logEvent();

        sharedPreferences=getSharedPreferences(getString(R.string.share),MODE_PRIVATE);

 if(savedInstanceState!=null){

}



        FragmentManager manager = getSupportFragmentManager();
        TrendingFragment mytrending = new TrendingFragment();
        manager.beginTransaction().replace(R.id.mydata, mytrending).commit();
        editor=sharedPreferences.edit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    public  void logEvent(){
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, String.valueOf(getTitle()));
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, getString(R.string.images));
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_favorites) {
            Intent i=new Intent(this,FavActivityScreen.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.trending) {
            FragmentManager manager = getSupportFragmentManager();
            TrendingFragment mytrending = new TrendingFragment();
            manager.beginTransaction().replace(R.id.mydata, mytrending).commit();

        } else if (id == R.id.business) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            BusinessFragment businessFragment=new BusinessFragment();
            fragmentManager.beginTransaction().replace(R.id.mydata,businessFragment).commit();

        } else if (id == R.id.entertainment) {
            FragmentManager EManager = getSupportFragmentManager();
            EntertainmentFragment entertainmentFragment=new EntertainmentFragment();
            EManager.beginTransaction().replace(R.id.mydata,entertainmentFragment).commit();
        } else if (id == R.id.sports) {

            FragmentManager smanager=getSupportFragmentManager();
            SportsFragment sportsFragment=new SportsFragment();
            smanager.beginTransaction().replace(R.id.mydata,sportsFragment).commit();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

}
