package com.example.acer.nationalnews;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class FavModel extends AndroidViewModel {
    FavRepos favRepos;
    LiveData<List<Nentity>> getLiveData;


    public FavModel(@NonNull Application application) {
        super(application);
        favRepos=new FavRepos(application);
        getLiveData=favRepos.getGetfavorites();
    }



    public void insertData(Nentity nentity)
    {
        favRepos.insert(nentity);
    }

    public LiveData<List<Nentity>> nentity()
    {
        return getLiveData;
    }
    public void deleteData(Nentity nentity)
    {
        favRepos.deleteData(nentity);
    }












}
