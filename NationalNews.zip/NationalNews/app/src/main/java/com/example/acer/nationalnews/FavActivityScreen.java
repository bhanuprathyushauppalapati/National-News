package com.example.acer.nationalnews;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class FavActivityScreen extends AppCompatActivity {

    FavModel favModel;
    RecyclerView recyclerView;
    ArrayList<Nentity> nentit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_screen);
        recyclerView=findViewById(R.id.recfav);


        favModel = ViewModelProviders.of(this).get(FavModel.class);
        favModel.getLiveData.observe(this, new Observer<List<Nentity>>() {
            @Override
            public void onChanged(@Nullable List<Nentity> nentities) {

                if(nentities.size()==0){
                    Toast.makeText(FavActivityScreen.this, getString(R.string.NoFavoritesAdded), Toast.LENGTH_SHORT).show();
                }
                else{

                    FavouriteAdapter adapter=new FavouriteAdapter(FavActivityScreen.this, (ArrayList<Nentity>) nentities);
                    recyclerView.setAdapter(adapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(FavActivityScreen.this));
                }


            }
        });
    }
}
